// complete the following such that a new array with only integers
// (while numbers) is returned

var arr = ['hello', 42, true, function() {}, "123", 3.14, 0, [1], {}];

var isInteger = function() {};

Array.prototype.filter = function() {};

var newArr = arr.filter(isInteger);
console.log(newArr);
